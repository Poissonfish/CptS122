#ifndef BST_H
#define BST_H

#include "BSTNode.h"

#include <iostream>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::string;

class BST
{
	public:
		BST();
		BST(BST &copy);		// deep copy
		~BST();

		void insertNode(string newData);
		void inOrderTraversal();
		void preOrderTraversal();
		void postOrderTraversal();
		bool isEmpty();

	private:
		BSTNode *mpRoot;

		void copyTreeHelper(BSTNode *currentNode);
		void destroyTreeHelper(BSTNode *currentNode);
		void insertNode(BSTNode *&currentNode, string newData);
		void inOrderTraversal(BSTNode *currentNode);
		void preOrderTraversal(BSTNode *currentNode);
		void postOrderTraversal(BSTNode *currentNode);
};

#endif