#include "BST.h"

BST::BST()
{
	this->mpRoot = nullptr;
}

BST::BST(BST &copy)		// deep copy
{
	this->mpRoot = nullptr;
	copyTreeHelper(copy.mpRoot);
}

BST::~BST()
{
	destroyTreeHelper(this->mpRoot);
}

// ======== public functions ========

void BST::insertNode(string newData)
{
	insertNode(this->mpRoot, newData);
}

void BST::inOrderTraversal()
{
	inOrderTraversal(this->mpRoot);
}

void BST::preOrderTraversal()
{
	preOrderTraversal(this->mpRoot);
}

void BST::postOrderTraversal()
{
	postOrderTraversal(this->mpRoot);
}

bool BST::isEmpty()
{
	return (this->mpRoot == nullptr);
}

// ======== private functions ========

void BST::copyTreeHelper(BSTNode *currentNode)
{
	if (currentNode != nullptr)
	{
		insertNode(currentNode->getData());
		copyTreeHelper(currentNode->getLeft());
		copyTreeHelper(currentNode->getRight());
	}
}

void BST::destroyTreeHelper(BSTNode *currentNode)
{
	if (currentNode != nullptr)
	{
		destroyTreeHelper(currentNode->getLeft());
		destroyTreeHelper(currentNode->getRight());
		delete currentNode;
	}
}

void BST::insertNode(BSTNode *&currentNode, string newData)
{
	if (currentNode == nullptr)
	{
		currentNode = new BSTNode(newData);
		return;
	}

	// newData is less
	if (newData < currentNode->getData())
	{
		// traverse left
		insertNode(currentNode->getLeft(), newData);
	}
	// newData is greater
	else if (newData > currentNode->getData())
	{
		// traverse right
		insertNode(currentNode->getRight(), newData);
	}
	// newData is equal
	else
	{
		// do nothing
	}
}

void BST::inOrderTraversal(BSTNode *currentNode)
{
	if (currentNode != nullptr)
	{
		inOrderTraversal(currentNode->getLeft());
		cout << *currentNode;
		inOrderTraversal(currentNode->getRight());
	}
}

void BST::preOrderTraversal(BSTNode *currentNode)
{
	if (currentNode != nullptr)
	{
		cout << currentNode;
		inOrderTraversal(currentNode->getLeft());
		inOrderTraversal(currentNode->getRight());
	}
}

void BST::postOrderTraversal(BSTNode *currentNode)
{
	if (currentNode != nullptr)
	{
		inOrderTraversal(currentNode->getLeft());
		inOrderTraversal(currentNode->getRight());
		cout << currentNode;
	}
}