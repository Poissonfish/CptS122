#ifndef BST_NODE_H
#define BST_NODE_H

#include <iostream>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::string;

class BSTNode
{
	public:
		BSTNode(string newData = "");
		BSTNode(BSTNode &copy);
		~BSTNode();

		// getters
		string getData();
		BSTNode *& getLeft();
		BSTNode *& getRight();

		// setters
		void setData(string newData);
		void setLeft(BSTNode *newLeft);
		void setRight(BSTNode *newRight);

	private:
		string data;
		BSTNode *left;
		BSTNode *right;
};

ostream & operator<< (ostream &lhs, BSTNode &rhs);

#endif